<?php 
class ControllerPaymentfetch extends Controller 
{
	private $error = array(); 
	public function index() {
		$this->load->language('payment/fetch');
		$this->document->setTitle($this->language->get('heading_title'));		
		$this->load->model('setting/setting');			
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {			
                    $this->model_setting_setting->editSetting('fetch', $this->request->post);
                    $this->session->data['success'] = $this->language->get('text_success');
                    $this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$this->data['heading_title'] = $this->language->get('heading_title');
		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_all_zones'] = $this->language->get('text_all_zones');
		
		$this->data['text_payment'] = $this->language->get('text_payment');
		$this->data['text_help'] = $this->language->get('text_help');
		$this->data['text_logos'] = $this->language->get('text_logos');	

		$this->data['entry_account_id'] = $this->language->get('entry_account_id');
		$this->data['entry_transaction_mode'] = $this->language->get('entry_transaction_mode');
		$this->data['entry_live_process_url'] = $this->language->get('entry_live_process_url');
		$this->data['entry_live_mns_url'] = $this->language->get('entry_live_mns_url');
		$this->data['entry_return_url'] = $this->language->get('entry_return_url');
		$this->data['entry_notification_url'] = $this->language->get('entry_notification_url');
		$this->data['entry_header_image'] = $this->language->get('entry_header_image');
		$this->data['entry_bottom_header_border_color'] = $this->language->get('entry_bottom_header_border_color');
		$this->data['entry_header_bg_color'] = $this->language->get('entry_header_bg_color');
		$this->data['entry_store_card'] = $this->language->get('entry_store_card');
		$this->data['entry_csc_required'] = $this->language->get('entry_csc_required');
		$this->data['entry_display_email'] = $this->language->get('entry_display_email');
		
		$this->data['entry_order_status'] = $this->language->get('entry_order_status');		
		$this->data['entry_failed_status'] = $this->language->get('entry_failed_status');		
		$this->data['entry_forged_status'] = $this->language->get('entry_forged_status');		
                $this->data['entry_status'] = $this->language->get('entry_status');
		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');
		$this->data['tab_general'] = $this->language->get('tab_general');

 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}
		
 		if (isset($this->error['account_id'])) {
			$this->data['error_account_id'] = $this->error['account_id'];
		} else {
			$this->data['error_account_id'] = '';
		}
		
		$this->data['breadcrumbs'] = array();
		
		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);
		
		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		$this->data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/fetch', 'token=' . $this->session->data['token'], 'SSL'),      		
      		'separator' => ' :: '
   		);
		
		$this->data['action'] = $this->url->link('payment/fetch', 'token=' . $this->session->data['token'], 'SSL');
		$this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
	
		if (isset($this->request->post['fetch_status'])) {
			$this->data['fetch_status'] = $this->request->post['fetch_status'];
		} else {
			$this->data['fetch_status'] = $this->config->get('fetch_status');
		}
		
		if (isset($this->request->post['fetch_account_id'])) {
			$this->data['fetch_account_id'] = $this->request->post['fetch_account_id'];
		} else {
			$this->data['fetch_account_id'] = $this->config->get('fetch_account_id');
		}
		
		if (isset($this->request->post['fetch_order_status_id'])) {
			$this->data['fetch_order_status_id'] = $this->request->post['fetch_order_status_id'];
		} else {
                    $order_status_id = (int)$this->config->get('fetch_order_status_id');
                    if ($order_status_id > 0) {
			$this->data['fetch_order_status_id'] = $this->config->get('fetch_order_status_id');
                    } else {
                        $order_state = $this->getOrderStateByName("Pending");
                        $this->data['fetch_order_status_id'] = $order_state['order_status_id'];
                    }
		}

		if (isset($this->request->post['fetch_failed_status_id'])) {
			$this->data['fetch_failed_status_id'] = $this->request->post['fetch_failed_status_id'];
		} else {
                    $order_status_id = (int)$this->config->get('fetch_failed_status_id');
                    if ($order_status_id > 0) {
			$this->data['fetch_failed_status_id'] = $this->config->get('fetch_failed_status_id'); 
                    } else {
                        $order_state = $this->getOrderStateByName("Failed");
                        $this->data['fetch_failed_status_id'] = $order_state['order_status_id'];
                    }
		} 
                
                //successful order status; 
		if (isset($this->request->post['fetch_forged_status_id'])) {   
			$this->data['fetch_forged_status_id'] = $this->request->post['fetch_forged_status_id'];
                        
		} else {
                    $order_status_id = (int)$this->config->get('fetch_forged_status_id');
                    if ($order_status_id > 0) {
			$this->data['fetch_forged_status_id'] = $this->config->get('fetch_forged_status_id'); 
                    } else {
                        $order_state = $this->getOrderStateByName("Processing");
                        $this->data['fetch_forged_status_id'] = $order_state['order_status_id'];
                    }
		}

		$this->load->model('localisation/order_status');
		$this->data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses(array('order'=>'ASC'));
		
		if (isset($this->request->post['fetch_geo_zone_id'])) {
			$this->data['fetch_geo_zone_id'] = $this->request->post['fetch_geo_zone_id'];
		} else {
			$this->data['fetch_geo_zone_id'] = $this->config->get('fetch_geo_zone_id'); 
		}
		
		$this->load->model('localisation/geo_zone');
										
		$this->data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
		
		
		if (isset($this->request->post['fetch_sort_order'])) {
			if(strlen($this->request->post['fetch_sort_order']) == 0){
				$this->data['fetch_sort_order'] = 1;	
			}else{
				$this->data['fetch_sort_order'] = $this->request->post['fetch_sort_order'];	
			}
		} else {
			if(strlen($this->config->get('fetch_sort_order')) == 0){
				$this->data['fetch_sort_order'] = 1;	
			}else{
				$this->data['fetch_sort_order'] = $this->config->get('fetch_sort_order');
			}
		}
		
		if (isset($this->request->post['fetch_transaction_mode'])) {
			$this->data['fetch_transaction_mode'] = $this->request->post['fetch_transaction_mode'];
		} else {
			$this->data['fetch_transaction_mode'] = $this->config->get('fetch_transaction_mode'); 
		}		
                
                if (isset($this->request->post['fetch_live_process_url'])) {
			$this->data['fetch_live_process_url'] = $this->request->post['fetch_live_process_url'];
		} else {
			$this->data['fetch_live_process_url'] = $this->config->get('fetch_live_process_url');
		}			
                
                if (isset($this->request->post['fetch_return_url'])) {
			$this->data['fetch_return_url'] = $this->request->post['fetch_return_url'];
		} else {
			$this->data['fetch_return_url'] = $this->config->get('fetch_return_url');
		}
                
                if (isset($this->request->post['fetch_notification_url'])) {
			$this->data['fetch_notification_url'] = $this->request->post['fetch_notification_url'];
		} else {
			$this->data['fetch_notification_url'] = $this->config->get('fetch_notification_url');
		}
                
                if (isset($this->request->post['fetch_live_mns_url'])) {
			$this->data['fetch_live_mns_url'] = $this->request->post['fetch_live_mns_url'];
		} else {
			$this->data['fetch_live_mns_url'] = $this->config->get('fetch_live_mns_url');
		}

		if (isset($this->request->post['fetch_header_image'])) {
			$this->data['fetch_header_image'] = $this->request->post['fetch_header_image'];
		} else {
			$this->data['fetch_header_image'] = $this->config->get('fetch_header_image');
		}

		if (isset($this->request->post['fetch_bottom_header_border_color'])) {
			$this->data['fetch_bottom_header_border_color'] = $this->request->post['fetch_bottom_header_border_color'];
		} else {
			$this->data['fetch_bottom_header_border_color'] = $this->config->get('fetch_bottom_header_border_color');
		}
		
		if (isset($this->request->post['fetch_header_bg_color'])) {
			$this->data['fetch_header_bg_color'] = $this->request->post['fetch_header_bg_color'];
		} else {
			$this->data['fetch_header_bg_color'] = $this->config->get('fetch_header_bg_color');
		}
		
		if (isset($this->request->post['fetch_store_card'])) {
			$this->data['fetch_store_card'] = $this->request->post['fetch_store_card'];
		} else {
			$this->data['fetch_store_card'] = $this->config->get('fetch_store_card');
		}
		
		if (isset($this->request->post['fetch_csc_required'])) {
			$this->data['fetch_csc_required'] = $this->request->post['fetch_csc_required'];
		} else {
			$this->data['fetch_csc_required'] = $this->config->get('fetch_csc_required');
		}
		
		if (isset($this->request->post['fetch_display_email'])) {
                    $this->data['fetch_display_email'] = $this->request->post['fetch_display_email'];
		} else {
                    $is_email = $this->config->get('fetch_display_email'); 
                    
                    if($is_email == null) {
                        $is_email = '1';
                    }
                    $this->data['fetch_display_email'] = $is_email;
		}
		
		$this->template = 'payment/fetch.tpl';
		$this->children = array(
			'common/header',	
			'common/footer'	
		);
                    
		$this->response->setOutput($this->render());
	}
        
        public function install() {
        }
        
        public function getOrderStateByName($order_state) {
            $rq = $this->db->query('SELECT * FROM `' .DB_PREFIX. 'order_status` WHERE `name` = \''. $order_state . '\'');
            if ($rq->num_rows) {
                return $rq->row;
            } else return FALSE;
        }
        
	private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/fetch')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}	
	}
}
?>