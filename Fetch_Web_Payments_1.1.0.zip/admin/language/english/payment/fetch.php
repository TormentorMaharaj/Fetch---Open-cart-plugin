<?php
// Heading
$_['heading_title']      = 'Fetch Web Payments';

// Text 
$_['text_fetch'] = '<a onclick="window.open(\'https://my.fetchpayments.co.nz/webpayments/default.aspx\');"><img src="../catalog/view/fetch/fetch_logo_sml.jpg" alt="Fetch Web Payments" title="Fetch Web Payments" /></a>';	
$_['text_payment'] = 'Payment:';
$_['text_success']       = 'Settings for Fetch Web Payments have been modified and saved successfully';
$_['text_redirect']		 = 'You will be redirected shortly';
$_['text_continue']		 = 'Continue';
$_['text_live_trans'] = 'Live transactions';
$_['text_yes'] = 'Yes';
$_['text_no'] = 'No';

// Entry
$_['entry_order_status'] = '<b>New order status: (optional)</b><br/><span class="help">The default status for a new order is \'Pending\'. The first option of the dropdown list will be the default state if \'Pending\' cannot be found in the database. If you would like this to be set to a different status before redirecting to Fetch select this status here.</span>';
$_['entry_failed_status'] = '<b>Order status when payment failed: (optional)</b><br/><span class="help">Orders will be moved to this status when a payment is not successful. If no option is chosen then the order will be moved to \'Failed\'. The first option of the dropdown list will be the default state if \'Failed\' cannot be found in the database.</span>';
//success status
$_['entry_forged_status'] = '<b>Order status when payment successful: (optional)</b><br/><span class="help">Orders will be moved to this status when a payment is successful. If no option is chosen then the order will be moved to \'Processing\'. The first option of the dropdown list will be the default state if \'Processing\' cannot be found in the database.</span>';
$_['entry_status']       = '<b>Status: (required)</b>';
$_['entry_account_id'] = '<b>Fetch Account ID: (required)</b>';
$_['entry_transaction_mode'] = '<b>Test/Demo mode: (required)</b>';
$_['entry_live_process_url'] = 'Live mode Process URL:';
$_['entry_live_mns_url'] = 'Live mode MNS URL:<br/><span class="help">If filled then this URL will be used for Fetch Merchant Notification Service</span>';
$_['entry_return_url'] = 'Return URL:<br/><span class="help">URL that the customer will be sent to on completion of the payment</span>';
$_['entry_notification_url'] = 'Notification URL:<br/><span class="help">URL where MNS (if active) will callback to start the MNS verification process</span>';
$_['entry_header_image'] = '<b>Header image URL: (optional)</b><br/><span class="help">URL of image displayed at top of payment page, max size: 750px wide by 90px high, must be URL encoded and stored on secure (HTTPS) server.';
$_['entry_bottom_header_border_color'] = '<b>Header border color: (optional)</b><br/><span class="help">This sets the colour of the bottom border of the payment page header. Values should be in hexadecimal e.g. FFFFFF for white.</span>';
$_['entry_header_bg_color'] = '<b>Header background color: (optional)</b><br/><span class="help">This sets the colour of the payment page header background. Values should be in hexadecimal e.g. FFFFFF for white.</span>';
$_['entry_store_card'] = '<b>Save card: (required)</b><br/><span class="help">Whether the option for saving and tokenising the card details upon a successful payment should be shown to the customer.</span>';
$_['entry_csc_required'] = 'CSC required:<br/><span class="help">Whether Web2Pay should display the CSC field when a client enters their credit card details</span>';
$_['entry_display_email'] = '<b>Display receipt email: (required)</b><br/><span class="help">Whether the option for sending an emailed payment receipt from Fetch should be shown to the customer.</span>';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Fetch Web Payments!';
$_['error_account_id']     = 'Account ID Required';

?>