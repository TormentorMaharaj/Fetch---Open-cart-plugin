<?php 
class ModelPaymentfetch extends Model
{
	public function getMethod($address, $total) 
	{
		$this -> language -> load('payment/fetch');		
		$method_data = array();
		
		if ($this -> config -> get('fetch_status')) 
		{
      		$query = $this -> db -> query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this -> config -> get('fetch_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
			
			if ((!$this -> config -> get('fetch_geo_zone_id')) || ($query -> num_rows))
			{
				$method_data = array( 
					'code'       => 'fetch',
					'title'      => $this -> language -> get('text_title'),
					'sort_order' => $this -> config -> get('fetch_sort_order')
				);
      		}
		}
	
    	return $method_data;
  	}
}
?>