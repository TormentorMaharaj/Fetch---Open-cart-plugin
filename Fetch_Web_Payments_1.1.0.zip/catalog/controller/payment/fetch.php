<?php
class ControllerPaymentfetch extends Controller 
{
	protected function index() {
		$this->load->model('checkout/order');
		$this->language->load('payment/fetch');
		
                $this->data['button_confirm'] = 'Make payment at Fetch';
		$this->data['button_back'] = $this->language->get('button_back');
                $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
                $this->data['action'] = $this->config->get('fetch_live_process_url');
		$this->data['account_id'] = trim($this->config->get('fetch_account_id'));
                $this->data['return_url'] = $this->url->link('payment/fetch/callback'); 
		$this->data['notification_url'] = $this->url->link('payment/fetch/MNSCheck');
		$this->data['header_image'] = trim($this->config->get('fetch_header_image'));
		$this->data['header_border_bottom'] = trim($this->config->get('fetch_bottom_header_border_color'));
		$this->data['header_background_colour'] = trim($this->config->get('fetch_header_bg_color'));
		$this->data['store_card'] = $this->config->get('fetch_store_card');
		$this->data['csc_required'] = $this->config->get('fetch_csc_required');
		$this->data['display_customer_email'] = $this->config->get('fetch_display_email');
		$this->data['amount'] = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

                
		$products = array();
                $k=1;
                if (array_key_exists('shipping_method', $this->session->data)) {
                    $shipping_arr = $this->session->data['shipping_method'];
                    if ($shipping_arr['text']) {
                        $shipping_price = str_replace("$", "", $shipping_arr['text']);      
                        $products['item_name'.$k] = $shipping_arr['title'].'(shipping)';
                        $products['item_price'.$k] = $shipping_price;
                        $products['item_code'.$k] = $k;
                        $products['item_qty'.$k] = '1';
                        $k++;
                    }
                }
                
		foreach ($this->cart->getProducts() as $val) {
                    if (floatval($val['total'])>0) {
                        $product_price_inc = $this->tax->calculate($val['price'], $val['tax_class_id']);
                        $products['item_name'.$k] = $val['name'];
                        $products['item_price'.$k] = $product_price_inc;
                        $products['item_code'.$k] = $val['product_id'];
                        $products['item_qty'.$k] = $val['quantity'];
                        $k++;
                    }
                }

                $this->data['products'] = $products;
		$this->data['order_id'] = $this->session->data['order_id'];
		$this->id = 'payment';
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/fetch.tpl')) {
			$this->template = $this->config->get('config_template') . '/template/payment/fetch.tpl';
		} else {
			$this->template = 'default/template/payment/fetch.tpl';
		}
                
                $this->render();
                
                $this->model_checkout_order->update($this->data['order_id'], $this->config->get('fetch_order_status_id'), '', TRUE);
		$this->model_checkout_order->confirm($this->data['order_id'], $this->config->get('fetch_order_status_id'));
		
	}
	
	public function callback() {  
            if ($_POST) {
		if (isset($this->request->post['reference'])) {
			$order_id = $this->request->post['reference'];
		} else {
			$order_id = 0;
		}
		$this->load->model('checkout/order');
		$PostData = "";		
		$order_info = $this->model_checkout_order->getOrder($order_id);
		
		if ($order_info) {
                    //store some data in the session so that we can display the result to the customer in the next screen
                    $this->session->data['txn_status'] = $this->request->post['txn_status'];
                    $this->session->data['txn_id'] = $this->request->post['txn_id'];
                    $this->session->data['receipt_no'] = $this->request->post['receipt_no'];
                    $this->session->data['response_text'] = $this->request->post['response_text'];

                    if ($this->request->post['txn_status'] == '2') {
                            $this->redirect($this->url->link('checkout/fetch_success'));
                    } else {
                            $this->redirect($this->url->link('checkout/fetch_failure'));
                    }
                } else {
                    $this->redirect($this->url->link('checkout/fetch_failure'));
                }
            } else {
                $this->cart->clear();
                $this->redirect($this->url->link('common/home'));
            }
	}
	
	public function MNSCheck() {
            if (isset($this->request->post['transaction_status'])) {
                    if (isset($this->request->post['reference'])) {
                            $order_id = $this->request->post['reference'];
                    } else {
                            $order_id = 0;
                    }
                    $this->load->model('checkout/order');
                    $PostData = "";
                    $order_info = $this->model_checkout_order->getOrder($order_id);
                    $MNSServerURL = $this->config->get('fetch_live_mns_url');

                    if ($order_info) {
                        $PostData =  $this->creatingVarificationPostedString($this->request->post);
                        $ActionResponse = $this->callAPI($MNSServerURL, $PostData);

                        if($ActionResponse == 'REJECTED'){                                    
                                $this->model_checkout_order->update($order_id, $this->config->get('fetch_rejected_status_id'), '', TRUE);
                                $this->model_checkout_order->confirm($order_id, $this->config->get('fetch_rejected_status_id'));
                        } else {
                            if ($this->request->post['transaction_status']=='2') {                                    
                                $this->model_checkout_order->update($order_id, $this->config->get('fetch_forged_status_id'), '', TRUE);
                                $this->model_checkout_order->confirm($order_id, $this->config->get('fetch_forged_status_id'));
                            } else {
                                $this->model_checkout_order->update($order_id, $this->config->get('fetch_failed_status_id'), '', TRUE);
                                $this->model_checkout_order->confirm($order_id, $this->config->get('fetch_failed_status_id'));
                            }
                        }
                    }
            }
    }
    
    public function creatingVarificationPostedString($array) {
        $post_data='';
        foreach ($array as $key => $value) {
            $post_data=$key.'='.urlencode($value).'&'.$post_data;
        }

        $post_data = $post_data . 'cmd=_xverify-transaction';
        return $post_data;
    }

    //call fetch API and return "VARIVIED" or "REJECTED" back
    public function callAPI($url, $post_data) {
        $response = '';
        try{
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_TIMEOUT, 100);
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            curl_setopt($ch, CURLOPT_NOPROGRESS, 0);
            $response = curl_exec($ch);            
            curl_close($ch);
        } catch (Exception $e) {
            throw new Exception("Invalid URL", 0, $e);
        }

        return $response;
    } 
}
?>