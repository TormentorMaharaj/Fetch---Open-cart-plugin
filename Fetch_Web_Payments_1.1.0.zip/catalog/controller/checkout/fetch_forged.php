<?php 
class ControllerCheckoutfetchForged extends Controller 
{ 
	public function index() 
	{ 
		if (isset($this -> session -> data['order_id'])) 
		{
			$orderID = $this -> session -> data['order_id'];
			
			$this -> cart -> clear();
			unset($this -> session -> data['shipping_method']);
			unset($this -> session -> data['shipping_methods']);
			unset($this -> session -> data['payment_method']);
			unset($this -> session -> data['payment_methods']);
			unset($this -> session -> data['guest']);
			unset($this -> session -> data['comment']);
			unset($this -> session -> data['order_id']);	
			unset($this -> session -> data['coupon']);
			unset($this -> session -> data['txn_status']);
			unset($this -> session -> data['txn_id']);
			unset($this -> session -> data['receipt_no']);
			unset($this -> session -> data['response_text']);
		}	

		$this -> language -> load('checkout/fetch_forged');
		$this -> document -> setTitle($this -> language -> get('heading_title'));	
		$this -> data['breadcrumbs'] = array(); 
		$this -> data['breadcrumbs'][] = array(
			'href'      => $this -> url -> link('common/home'),
			'text'      => $this -> language -> get('text_home'),			
      		'separator' => FALSE
   		);
		
		$this -> data['breadcrumbs'][] = array(
			'href'      => $this -> url -> link('checkout/cart'),
			'text'      => $this -> language -> get('text_basket'),			
      		'separator' => $this -> language -> get('text_separator')
   		);		
		
		if ($this -> customer -> isLogged()) 
		{
			$this -> data['breadcrumbs'][] = array(
				'href'      => $this -> url -> link('checkout/shipping'),
				'text'      => $this -> language -> get('text_shipping'),			
				'separator' => $this -> language -> get('text_separator')
			);		
			
			$this -> data['breadcrumbs'][] = array(
				'href'      => $this -> url -> link('checkout/payment'),
				'text'      => $this -> language -> get('text_payment'),			
				'separator' => $this -> language -> get('text_separator')
			);

			$this -> data['breadcrumbs'][] = array(
				'href'      => $this -> url -> link('checkout/confirm'),
				'text'      => $this -> language -> get('text_confirm'),			
				'separator' => $this -> language -> get('text_separator')
			);
		} 
		else 
		{
			$this -> data['breadcrumbs'][] = array(
				'href'      => $this -> url -> link('checkout/guest'),
				'text'      => $this -> language -> get('text_guest'),			
				'separator' => $this -> language -> get('text_separator')
			);

			$this -> data['breadcrumbs'][] = array(
				'href'      => $this -> url -> link('checkout/guest/confirm'),
				'text'      => $this -> language -> get('text_confirm'),			
				'separator' => $this -> language -> get('text_separator')
			);			
		}
		
		$this -> data['breadcrumbs'][] = array(
			'href'      => $this -> url -> link('checkout/success'),
			'text'      => $this -> language -> get('text_success'),			
			'separator' => $this -> language -> get('text_separator')
		);
		
    	$this -> data['heading_title'] = $this -> language -> get('heading_title');
    	$this -> data['text_message'] = sprintf($this -> language -> get('text_message'), $orderID, HTTPS_SERVER . 'index.php?route=account/account', HTTPS_SERVER . 'index.php?route=account/history', HTTP_SERVER . 'index.php?route=information/contact');
    	$this -> data['button_continue'] = $this -> language -> get('button_continue');
		$this -> data['continue'] = $this -> url -> link('common/home');
		
		$this -> template = 'default/template/common/success.tpl';
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/common/success.tpl')) 
		{
			$this -> template = $this -> config -> get('config_template') . '/template/common/success.tpl';
		} 
		
		$this -> children = array(
			'common/column_right',
			'common/footer',
			'common/content_top',
			'common/content_bottom',
			'common/column_left',
			'common/header'
		);
		
		$this -> response -> setOutput($this -> render());
  	}
}
?>